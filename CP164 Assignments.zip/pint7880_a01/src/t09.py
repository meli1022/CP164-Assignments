"""
------------------------------------------------------------------------
Question 9
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-01-16"
------------------------------------------------------------------------
"""
import functions

s = "I think your book is an utter piece of Garbage."

out = functions.dsmvwl(s)

print(out)
"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-02-06"
------------------------------------------------------------------------
"""
import functions
import Graph

graph = Graph.Graph
    

start_node = "A"
functions.prims(graph, start_node)
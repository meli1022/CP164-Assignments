"""
------------------------------------------------------------------------
Question 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-01-30"
------------------------------------------------------------------------
"""
from Stack_array import Stack



target = stack_combine(source1, source2)

print(target)
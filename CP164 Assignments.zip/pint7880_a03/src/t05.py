"""
------------------------------------------------------------------------
Question 5
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-01-30"
------------------------------------------------------------------------
"""
import functions

string = "blah"

p = functions.is_palindrome_stack(string)

print(p)